package com.lushprojects.circuitjs1.client;


public class PDarlingtonElm extends DarlingtonElm {



    public PDarlingtonElm(int xx, int yy) {
	super(xx, yy, true);
    }


    Class getDumpClass() {
	return DarlingtonElm.class;
    }
}

